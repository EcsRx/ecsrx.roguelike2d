using System;
using UnityEngine;

namespace Zenject.Tests.ToPrefabResource
{
    public interface INorf
    {
    }

    public class Norf : MonoBehaviour, INorf
    {
    }
}
