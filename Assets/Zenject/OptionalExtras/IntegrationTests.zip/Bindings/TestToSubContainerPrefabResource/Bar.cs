using UnityEngine;

namespace Zenject.Tests.ToSubContainerPrefabResource
{
    public class Bar : MonoBehaviour
    {
    }
}

