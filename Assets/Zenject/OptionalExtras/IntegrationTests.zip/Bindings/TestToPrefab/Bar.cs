﻿using UnityEngine;

namespace Zenject.Tests.ToPrefab
{
    public class Bar : MonoBehaviour
    {
    }
}
