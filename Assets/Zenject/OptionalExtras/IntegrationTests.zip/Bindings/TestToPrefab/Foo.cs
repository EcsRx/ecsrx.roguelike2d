﻿using UnityEngine;

namespace Zenject.Tests.ToPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
